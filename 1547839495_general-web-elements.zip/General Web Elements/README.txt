General Web Elements
====================

Designer: K. Lyn (https://www.iconfinder.com/klynart)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
